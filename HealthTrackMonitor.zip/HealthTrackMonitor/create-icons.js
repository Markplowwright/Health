import fs from 'fs';
import sharp from 'sharp';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function createIcons() {
  const svgBuffer = fs.readFileSync(path.join(__dirname, 'public', 'icons', 'icon.svg'));
  
  // Create 192x192 icon
  await sharp(svgBuffer)
    .resize(192, 192)
    .png()
    .toFile(path.join(__dirname, 'public', 'icons', 'icon-192.png'));
  
  console.log('Created 192x192 icon');
  
  // Create 512x512 icon
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.join(__dirname, 'public', 'icons', 'icon-512.png'));
  
  console.log('Created 512x512 icon');
}

createIcons().catch(err => console.error('Error creating icons:', err));