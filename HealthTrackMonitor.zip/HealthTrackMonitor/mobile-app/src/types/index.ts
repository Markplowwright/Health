// User related types
export interface User {
  id: number;
  username: string;
  fullName: string;
  email?: string;
  phoneNumber?: string;
  role?: string;
  profilePicture?: string;
}

// Vital related types
export interface Vital {
  id: number;
  userId: number;
  type: string;
  value: number;
  unit: string;
  timestamp: string;
  notes?: string;
}

// Notification related types
export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  type: string;
  timestamp: string;
  isRead: boolean;
}

// Medication related types
export interface Medication {
  id: number;
  userId: number;
  name: string;
  dosage: string;
  frequency: string;
  startDate: string;
  endDate?: string;
  instructions?: string;
  remainingDoses?: number;
  status: 'active' | 'completed';
}

// Appointment related types
export interface Appointment {
  id: number;
  userId: number;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  location: string;
  status: 'upcoming' | 'past' | 'cancelled';
  notes?: string;
}

// Message related types
export interface Message {
  id: number;
  senderId: number;
  receiverId: number;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface Contact {
  id: number;
  name: string;
  role: string;
  lastMessage: string;
  lastMessageTime: string;
  unread: boolean;
}