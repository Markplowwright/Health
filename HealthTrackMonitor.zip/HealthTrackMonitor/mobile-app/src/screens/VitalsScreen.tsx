import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Modal,
  Platform
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../App';
import { getVitals, addVital } from '../api/client';
import { Vital } from '../types';

type VitalsScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Vitals'>;
type VitalsScreenRouteProp = RouteProp<RootStackParamList, 'Vitals'>;

interface VitalsScreenProps {
  navigation: VitalsScreenNavigationProp;
  route: VitalsScreenRouteProp;
}

interface VitalTypeInfo {
  label: string;
  unit: string;
  icon: string;
  minValue: number;
  maxValue: number;
}

const VITAL_TYPES: Record<string, VitalTypeInfo> = {
  'Heart Rate': {
    label: 'Heart Rate',
    unit: 'bpm',
    icon: '❤️',
    minValue: 40,
    maxValue: 200
  },
  'Blood Pressure': {
    label: 'Blood Pressure',
    unit: 'mmHg',
    icon: '🩸',
    minValue: 70,
    maxValue: 200
  },
  'Blood Oxygen': {
    label: 'Blood Oxygen',
    unit: '%',
    icon: '💨',
    minValue: 80,
    maxValue: 100
  },
  'Temperature': {
    label: 'Temperature',
    unit: '°C',
    icon: '🌡️',
    minValue: 35,
    maxValue: 42
  }
};

export default function VitalsScreen({ navigation, route }: VitalsScreenProps) {
  const { userId } = route.params;
  const [vitals, setVitals] = useState<Vital[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedVitalType, setSelectedVitalType] = useState<string>('');
  const [vitalValue, setVitalValue] = useState('');
  const [vitalNotes, setVitalNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fetchVitals = async () => {
    try {
      setLoading(true);
      const vitalsData = await getVitals(userId);
      setVitals(vitalsData);
    } catch (error) {
      console.error('Error fetching vitals:', error);
      Alert.alert('Error', 'Failed to load vitals data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchVitals();
  }, [userId]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchVitals();
  };

  const openAddVitalModal = (vitalType: string) => {
    setSelectedVitalType(vitalType);
    setVitalValue('');
    setVitalNotes('');
    setModalVisible(true);
  };

  const handleAddVital = async () => {
    if (!selectedVitalType || !vitalValue) {
      Alert.alert('Error', 'Please enter a value for the vital');
      return;
    }

    const numValue = parseFloat(vitalValue);
    if (isNaN(numValue)) {
      Alert.alert('Error', 'Please enter a valid number');
      return;
    }

    const vitalInfo = VITAL_TYPES[selectedVitalType];
    if (numValue < vitalInfo.minValue || numValue > vitalInfo.maxValue) {
      Alert.alert(
        'Warning', 
        `The value you entered seems outside the normal range (${vitalInfo.minValue}-${vitalInfo.maxValue}). Are you sure?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Yes, continue', onPress: () => submitVital(numValue) }
        ]
      );
      return;
    }

    submitVital(numValue);
  };

  const submitVital = async (value: number) => {
    try {
      setSubmitting(true);
      
      const newVital = {
        userId,
        type: selectedVitalType,
        value,
        unit: VITAL_TYPES[selectedVitalType].unit,
        timestamp: new Date().toISOString(),
        notes: vitalNotes || undefined
      };
      
      await addVital(newVital);
      
      setModalVisible(false);
      fetchVitals(); // Refresh the list
      
      Alert.alert('Success', `${selectedVitalType} has been recorded`);
    } catch (error) {
      console.error('Error adding vital:', error);
      Alert.alert('Error', 'Failed to record vital data');
    } finally {
      setSubmitting(false);
    }
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getVitalsByType = (type: string): Vital[] => {
    return vitals.filter(vital => vital.type === type);
  };

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2C64F5" />
        <Text style={styles.loadingText}>Loading vitals data...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Vitals Sections */}
        {Object.keys(VITAL_TYPES).map(vitalType => (
          <View key={vitalType} style={styles.vitalSection}>
            <View style={styles.vitalTypeHeader}>
              <View style={styles.vitalTypeInfo}>
                <Text style={styles.vitalTypeIcon}>{VITAL_TYPES[vitalType].icon}</Text>
                <Text style={styles.vitalTypeTitle}>{vitalType}</Text>
              </View>
              <TouchableOpacity 
                style={styles.addButton}
                onPress={() => openAddVitalModal(vitalType)}
              >
                <Text style={styles.addButtonText}>+ Add</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.vitalHistory}>
              {getVitalsByType(vitalType).length > 0 ? (
                getVitalsByType(vitalType)
                  .slice(0, 5) // Show only the last 5 readings
                  .map((vital, index) => (
                    <View key={index} style={styles.vitalRecord}>
                      <Text style={styles.vitalValue}>
                        {vital.value} {vital.unit}
                      </Text>
                      <Text style={styles.vitalDate}>{formatDate(vital.timestamp)}</Text>
                      {vital.notes && (
                        <Text style={styles.vitalNotes}>{vital.notes}</Text>
                      )}
                    </View>
                  ))
              ) : (
                <Text style={styles.noDataText}>No {vitalType.toLowerCase()} data recorded yet</Text>
              )}
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Add Vital Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                Add {selectedVitalType} Reading
              </Text>
              <TouchableOpacity 
                style={styles.closeButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.closeButtonText}>✕</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.inputLabel}>
              Value ({VITAL_TYPES[selectedVitalType]?.unit || ''}):
            </Text>
            <TextInput
              style={styles.input}
              value={vitalValue}
              onChangeText={setVitalValue}
              keyboardType="numeric"
              placeholder={`Enter ${selectedVitalType} value`}
            />

            <Text style={styles.inputLabel}>Notes (optional):</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={vitalNotes}
              onChangeText={setVitalNotes}
              placeholder="Add any additional notes"
              multiline
              numberOfLines={4}
            />

            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleAddVital}
              disabled={submitting}
            >
              {submitting ? (
                <ActivityIndicator color="#ffffff" />
              ) : (
                <Text style={styles.submitButtonText}>Save</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  vitalSection: {
    backgroundColor: 'white',
    margin: 16,
    marginBottom: 8,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  vitalTypeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  vitalTypeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  vitalTypeIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  vitalTypeTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  addButton: {
    backgroundColor: '#2C64F5',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  addButtonText: {
    color: 'white',
    fontWeight: '500',
  },
  vitalHistory: {
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    padding: 12,
  },
  vitalRecord: {
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
    paddingVertical: 12,
  },
  vitalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  vitalDate: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  vitalNotes: {
    fontSize: 14,
    color: '#888',
    fontStyle: 'italic',
  },
  noDataText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    padding: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '85%',
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  closeButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#F2F2F2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 16,
    color: '#666',
  },
  inputLabel: {
    fontSize: 16,
    color: '#444',
    marginBottom: 8,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontSize: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: '#2C64F5',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 10,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});