import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../App';

type AppointmentsScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Appointments'>;
type AppointmentsScreenRouteProp = RouteProp<RootStackParamList, 'Appointments'>;

interface AppointmentsScreenProps {
  navigation: AppointmentsScreenNavigationProp;
  route: AppointmentsScreenRouteProp;
}

// Sample appointment data for UI demonstration
const SAMPLE_APPOINTMENTS = [
  {
    id: 1,
    doctorName: 'Dr. Emily Chen',
    specialty: 'Cardiology',
    date: '2025-04-15',
    time: '10:30 AM',
    location: 'Heart Health Clinic, Building A, Floor 3',
    status: 'upcoming',
    notes: 'Annual heart checkup. Bring previous test results.'
  },
  {
    id: 2,
    doctorName: 'Dr. Michael Wilson',
    specialty: 'Endocrinology',
    date: '2025-04-22',
    time: '2:00 PM',
    location: 'Diabetes Care Center, Suite 205',
    status: 'upcoming',
    notes: 'Follow-up for medication adjustment.'
  },
  {
    id: 3,
    doctorName: 'Dr. Sarah Johnson',
    specialty: 'Primary Care',
    date: '2025-03-10',
    time: '9:15 AM',
    location: 'Community Medical Center',
    status: 'past',
    notes: 'Regular check-up and blood work.'
  }
];

export default function AppointmentsScreen({ route }: AppointmentsScreenProps) {
  const { userId } = route.params;
  const [loading] = useState(false);
  const [activeTab, setActiveTab] = useState('upcoming');

  // Filter appointments by status
  const filteredAppointments = SAMPLE_APPOINTMENTS.filter(
    appointment => appointment.status === activeTab
  );

  // Format date to more readable format
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2C64F5" />
        <Text style={styles.loadingText}>Loading appointments...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'upcoming' && styles.activeTab
          ]}
          onPress={() => setActiveTab('upcoming')}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'upcoming' && styles.activeTabText
          ]}>
            Upcoming
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'past' && styles.activeTab
          ]}
          onPress={() => setActiveTab('past')}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'past' && styles.activeTabText
          ]}>
            Past
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.headerContainer}>
        <Text style={styles.headerTitle}>
          {activeTab === 'upcoming' ? 'Upcoming Appointments' : 'Past Appointments'}
        </Text>
        <TouchableOpacity style={styles.scheduleButton}>
          <Text style={styles.scheduleButtonText}>Schedule New</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollContainer}>
        {filteredAppointments.length > 0 ? (
          filteredAppointments.map(appointment => (
            <View key={appointment.id} style={styles.appointmentCard}>
              <View style={styles.dateTimeContainer}>
                <Text style={styles.dateText}>{formatDate(appointment.date)}</Text>
                <Text style={styles.timeText}>{appointment.time}</Text>
              </View>
              
              <View style={styles.divider} />
              
              <View style={styles.doctorInfoContainer}>
                <View style={styles.doctorIconContainer}>
                  <Text style={styles.doctorIcon}>👨‍⚕️</Text>
                </View>
                <View style={styles.doctorDetails}>
                  <Text style={styles.doctorName}>{appointment.doctorName}</Text>
                  <Text style={styles.specialty}>{appointment.specialty}</Text>
                </View>
              </View>
              
              <View style={styles.appointmentDetails}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailIcon}>📍</Text>
                  <Text style={styles.detailText}>{appointment.location}</Text>
                </View>
                
                {appointment.notes && (
                  <View style={styles.detailRow}>
                    <Text style={styles.detailIcon}>📝</Text>
                    <Text style={styles.detailText}>{appointment.notes}</Text>
                  </View>
                )}
              </View>
              
              {activeTab === 'upcoming' && (
                <View style={styles.actionContainer}>
                  <TouchableOpacity style={styles.rescheduleButton}>
                    <Text style={styles.rescheduleButtonText}>Reschedule</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.cancelButton}>
                    <Text style={styles.cancelButtonText}>Cancel</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>
              {activeTab === 'upcoming' 
                ? 'No upcoming appointments. Schedule your next visit with a doctor.'
                : 'No past appointments found.'}
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#2C64F5',
  },
  tabText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  activeTabText: {
    color: '#2C64F5',
    fontWeight: '600',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  scheduleButton: {
    backgroundColor: '#2C64F5',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  scheduleButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
  scrollContainer: {
    flex: 1,
  },
  appointmentCard: {
    backgroundColor: 'white',
    margin: 16,
    marginBottom: 8,
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  dateTimeContainer: {
    backgroundColor: '#F5F7FA',
    padding: 16,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  dateText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  timeText: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  divider: {
    height: 1,
    backgroundColor: '#E8E8E8',
  },
  doctorInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  doctorIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E6F7FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  doctorIcon: {
    fontSize: 24,
  },
  doctorDetails: {
    flex: 1,
  },
  doctorName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  specialty: {
    fontSize: 14,
    color: '#666',
  },
  appointmentDetails: {
    padding: 16,
    paddingTop: 0,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: 12,
  },
  detailIcon: {
    fontSize: 16,
    marginRight: 8,
    width: 20,
  },
  detailText: {
    flex: 1,
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  actionContainer: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#E8E8E8',
    padding: 12,
  },
  rescheduleButton: {
    flex: 1,
    backgroundColor: '#E6F7FF',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 8,
  },
  rescheduleButtonText: {
    color: '#2C64F5',
    fontWeight: '500',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#FFF1F0',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  cancelButtonText: {
    color: '#F5222D',
    fontWeight: '500',
  },
  emptyState: {
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});