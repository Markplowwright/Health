import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Alert
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../App';
import { getUserData, getLatestVitals, getNotifications } from '../api/client';
import { User, Vital, Notification } from '../types';

type DashboardScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Dashboard'>;
type DashboardScreenRouteProp = RouteProp<RootStackParamList, 'Dashboard'>;

interface DashboardScreenProps {
  navigation: DashboardScreenNavigationProp;
  route: DashboardScreenRouteProp;
}

export default function DashboardScreen({ navigation, route }: DashboardScreenProps) {
  const { userId } = route.params;
  const [user, setUser] = useState<User | null>(null);
  const [vitals, setVitals] = useState<Record<string, Vital>>({});
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      // Fetch user data
      const userData = await getUserData(userId);
      setUser(userData);

      // Fetch latest vitals
      const vitalsData = await getLatestVitals(userId);
      setVitals(vitalsData);

      // Fetch notifications
      const notificationsData = await getNotifications(userId);
      setNotifications(notificationsData);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      Alert.alert('Error', 'Failed to load dashboard data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [userId]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchDashboardData();
  };

  const handleNavigateToVitals = () => {
    navigation.navigate('Vitals', { userId });
  };

  const handleNavigateToMedications = () => {
    navigation.navigate('Medications', { userId });
  };

  const handleNavigateToAppointments = () => {
    navigation.navigate('Appointments', { userId });
  };

  const handleNavigateToMessages = () => {
    navigation.navigate('Messages', { userId });
  };

  const handleNavigateToProfile = () => {
    navigation.navigate('Profile', { userId });
  };

  const getVitalStatusColor = (type: string, value: number): string => {
    // Simple logic to determine status color based on vital type and value
    switch (type) {
      case 'Heart Rate':
        return value < 60 || value > 100 ? '#FF4D4F' : value < 70 || value > 90 ? '#FAAD14' : '#52C41A';
      case 'Blood Pressure':
        return value < 90 || value > 140 ? '#FF4D4F' : value < 110 || value > 130 ? '#FAAD14' : '#52C41A';
      case 'Blood Oxygen':
        return value < 95 ? '#FF4D4F' : value < 97 ? '#FAAD14' : '#52C41A';
      case 'Temperature':
        return value < 36 || value > 38 ? '#FF4D4F' : value < 36.5 || value > 37.5 ? '#FAAD14' : '#52C41A';
      default:
        return '#52C41A';
    }
  };

  const getTimeFromDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2C64F5" />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      {/* Welcome Section */}
      <View style={styles.welcomeSection}>
        <Text style={styles.welcomeText}>
          Hello, {user?.fullName || 'Patient'}
        </Text>
        <Text style={styles.dateText}>
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            month: 'long', 
            day: 'numeric' 
          })}
        </Text>
      </View>

      {/* Vitals Overview */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Vitals Overview</Text>
          <TouchableOpacity onPress={handleNavigateToVitals}>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.vitalsGrid}>
          {Object.keys(vitals).length > 0 ? (
            Object.entries(vitals).map(([type, vital]) => (
              <View key={type} style={styles.vitalCard}>
                <View style={styles.vitalHeader}>
                  <Text style={styles.vitalTitle}>{type}</Text>
                  <View 
                    style={[
                      styles.statusDot, 
                      { backgroundColor: getVitalStatusColor(type, vital.value) }
                    ]} 
                  />
                </View>
                <Text style={styles.vitalValue}>
                  {vital.value} {vital.unit}
                </Text>
                <Text style={styles.vitalTimestamp}>
                  Last updated: {getTimeFromDate(vital.timestamp)}
                </Text>
              </View>
            ))
          ) : (
            <Text style={styles.noDataText}>No vitals data available</Text>
          )}
        </View>
      </View>

      {/* Notifications */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Notifications</Text>
        </View>
        
        {notifications.length > 0 ? (
          notifications.slice(0, 3).map((notification) => (
            <View key={notification.id} style={styles.notificationCard}>
              <View style={styles.notificationHeader}>
                <Text style={styles.notificationTitle}>{notification.title}</Text>
                <Text style={styles.notificationTime}>
                  {getTimeFromDate(notification.timestamp)}
                </Text>
              </View>
              <Text style={styles.notificationMessage}>{notification.message}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.noDataText}>No notifications</Text>
        )}
      </View>

      {/* Quick Access Menu */}
      <View style={styles.quickAccessContainer}>
        <Text style={styles.sectionTitle}>Quick Access</Text>
        <View style={styles.menuGrid}>
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={handleNavigateToVitals}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#E6F7FF' }]}>
              <Text style={styles.menuIconText}>❤️</Text>
            </View>
            <Text style={styles.menuText}>Vitals</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={handleNavigateToMedications}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#FFF7E6' }]}>
              <Text style={styles.menuIconText}>💊</Text>
            </View>
            <Text style={styles.menuText}>Medications</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={handleNavigateToAppointments}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#F9F0FF' }]}>
              <Text style={styles.menuIconText}>📅</Text>
            </View>
            <Text style={styles.menuText}>Appointments</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={handleNavigateToMessages}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#E6FFFB' }]}>
              <Text style={styles.menuIconText}>💬</Text>
            </View>
            <Text style={styles.menuText}>Messages</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={handleNavigateToProfile}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#FCF5E5' }]}>
              <Text style={styles.menuIconText}>👤</Text>
            </View>
            <Text style={styles.menuText}>Profile</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  welcomeSection: {
    padding: 20,
    backgroundColor: '#2C64F5',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  dateText: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  sectionContainer: {
    backgroundColor: 'white',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  seeAllText: {
    fontSize: 14,
    color: '#2C64F5',
  },
  vitalsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  vitalCard: {
    width: '48%',
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
  },
  vitalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  vitalTitle: {
    fontSize: 14,
    color: '#666',
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  vitalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  vitalTimestamp: {
    fontSize: 12,
    color: '#999',
  },
  notificationCard: {
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  notificationTime: {
    fontSize: 12,
    color: '#999',
  },
  notificationMessage: {
    fontSize: 14,
    color: '#666',
  },
  quickAccessContainer: {
    margin: 16,
    marginTop: 0,
    padding: 16,
    backgroundColor: 'white',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  menuItem: {
    width: '30%',
    alignItems: 'center',
    marginBottom: 20,
  },
  menuIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  menuIconText: {
    fontSize: 24,
  },
  menuText: {
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
  },
  noDataText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    padding: 16,
  },
});