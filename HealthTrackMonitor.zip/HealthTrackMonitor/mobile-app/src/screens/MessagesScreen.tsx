import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../App';

type MessagesScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Messages'>;
type MessagesScreenRouteProp = RouteProp<RootStackParamList, 'Messages'>;

interface MessagesScreenProps {
  navigation: MessagesScreenNavigationProp;
  route: MessagesScreenRouteProp;
}

interface Contact {
  id: number;
  name: string;
  role: string;
  lastMessage: string;
  lastMessageTime: string;
  unread: boolean;
}

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'doctor';
  timestamp: string;
}

// Sample contacts data for UI demonstration
const SAMPLE_CONTACTS: Contact[] = [
  {
    id: 1,
    name: 'Dr. Emily Chen',
    role: 'Cardiologist',
    lastMessage: 'Your test results look good. Keep up with the medication.',
    lastMessageTime: '10:30 AM',
    unread: true,
  },
  {
    id: 2,
    name: 'Dr. Michael Wilson',
    role: 'Endocrinologist',
    lastMessage: 'We need to adjust your insulin dosage.',
    lastMessageTime: 'Yesterday',
    unread: false,
  },
  {
    id: 3,
    name: 'Dr. Sarah Johnson',
    role: 'Primary Care',
    lastMessage: 'Don\'t forget your annual checkup next month.',
    lastMessageTime: 'Tue',
    unread: false,
  },
];

// Sample conversation data for UI demonstration
const SAMPLE_CONVERSATION: Message[] = [
  {
    id: 1,
    text: 'Hello, how are you feeling today?',
    sender: 'doctor',
    timestamp: '10:00 AM',
  },
  {
    id: 2,
    text: 'I\'m feeling much better after starting the new medication. The chest pain has decreased significantly.',
    sender: 'user',
    timestamp: '10:05 AM',
  },
  {
    id: 3,
    text: 'That\'s great news! Any side effects from the medication?',
    sender: 'doctor',
    timestamp: '10:10 AM',
  },
  {
    id: 4,
    text: 'Just a little drowsiness in the mornings, but it\'s manageable.',
    sender: 'user',
    timestamp: '10:15 AM',
  },
  {
    id: 5,
    text: 'That\'s common and usually goes away after a week or two. Let\'s keep monitoring your symptoms and I\'ll see you at your next appointment.',
    sender: 'doctor',
    timestamp: '10:20 AM',
  },
  {
    id: 6,
    text: 'Your test results look good. Keep up with the medication.',
    sender: 'doctor',
    timestamp: '10:30 AM',
  },
];

export default function MessagesScreen({ route }: MessagesScreenProps) {
  const { userId } = route.params;
  const [loading] = useState(false);
  const [contacts] = useState<Contact[]>(SAMPLE_CONTACTS);
  const [activeContact, setActiveContact] = useState<Contact | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');

  const handleContactSelect = (contact: Contact) => {
    setActiveContact(contact);
    // In a real app, we would fetch messages for this contact from the API
    setMessages(SAMPLE_CONVERSATION);
  };

  const handleSendMessage = () => {
    if (newMessage.trim() === '') return;
    
    const newMessageObj: Message = {
      id: Date.now(),
      text: newMessage,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    
    setMessages([...messages, newMessageObj]);
    setNewMessage('');
    
    // In a real app, we would send the message to the API here
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2C64F5" />
        <Text style={styles.loadingText}>Loading messages...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {!activeContact ? (
        // Contact list view
        <View style={styles.contactsContainer}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Messages</Text>
            <TouchableOpacity style={styles.newChatButton}>
              <Text style={styles.newChatButtonText}>New Message</Text>
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={contacts}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity 
                style={styles.contactItem}
                onPress={() => handleContactSelect(item)}
              >
                <View style={styles.contactAvatar}>
                  <Text style={styles.contactInitial}>{item.name.charAt(0)}</Text>
                </View>
                
                <View style={styles.contactInfo}>
                  <View style={styles.contactHeader}>
                    <Text style={styles.contactName}>{item.name}</Text>
                    <Text style={styles.lastMessageTime}>{item.lastMessageTime}</Text>
                  </View>
                  
                  <Text style={styles.contactRole}>{item.role}</Text>
                  
                  <View style={styles.lastMessageContainer}>
                    <Text 
                      style={[
                        styles.lastMessage,
                        item.unread && styles.unreadMessage
                      ]} 
                      numberOfLines={1}
                    >
                      {item.lastMessage}
                    </Text>
                    
                    {item.unread && (
                      <View style={styles.unreadBadge}>
                        <Text style={styles.unreadBadgeText}>1</Text>
                      </View>
                    )}
                  </View>
                </View>
              </TouchableOpacity>
            )}
            ItemSeparatorComponent={() => <View style={styles.separator} />}
          />
        </View>
      ) : (
        // Conversation view
        <KeyboardAvoidingView 
          style={styles.conversationContainer}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
        >
          <View style={styles.conversationHeader}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => setActiveContact(null)}
            >
              <Text style={styles.backButtonText}>Back</Text>
            </TouchableOpacity>
            
            <View style={styles.contactTitleContainer}>
              <Text style={styles.contactTitle}>{activeContact.name}</Text>
              <Text style={styles.contactSubtitle}>{activeContact.role}</Text>
            </View>
          </View>
          
          <FlatList
            data={messages}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View 
                style={[
                  styles.messageContainer,
                  item.sender === 'user' ? styles.userMessage : styles.doctorMessage
                ]}
              >
                <View 
                  style={[
                    styles.messageBubble,
                    item.sender === 'user' ? styles.userBubble : styles.doctorBubble
                  ]}
                >
                  <Text style={styles.messageText}>{item.text}</Text>
                  <Text style={styles.messageTimestamp}>{item.timestamp}</Text>
                </View>
              </View>
            )}
            inverted={false}
            contentContainerStyle={styles.messagesContainer}
          />
          
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={newMessage}
              onChangeText={setNewMessage}
              placeholder="Type a message..."
              multiline
            />
            <TouchableOpacity 
              style={styles.sendButton}
              onPress={handleSendMessage}
              disabled={newMessage.trim() === ''}
            >
              <Text style={styles.sendButtonText}>Send</Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  contactsContainer: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  newChatButton: {
    backgroundColor: '#2C64F5',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  newChatButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
  contactItem: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: 'white',
  },
  contactAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#2C64F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  contactInitial: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  contactInfo: {
    flex: 1,
  },
  contactHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  contactName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  lastMessageTime: {
    fontSize: 12,
    color: '#999',
  },
  contactRole: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  lastMessageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  lastMessage: {
    fontSize: 14,
    color: '#999',
    flex: 1,
  },
  unreadMessage: {
    fontWeight: '600',
    color: '#333',
  },
  unreadBadge: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#2C64F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  unreadBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  separator: {
    height: 1,
    backgroundColor: '#E8E8E8',
    marginLeft: 66,
  },
  conversationContainer: {
    flex: 1,
  },
  conversationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  backButton: {
    marginRight: 16,
  },
  backButtonText: {
    fontSize: 16,
    color: '#2C64F5',
  },
  contactTitleContainer: {
    flex: 1,
  },
  contactTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  contactSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  messagesContainer: {
    padding: 16,
  },
  messageContainer: {
    marginBottom: 16,
    flexDirection: 'row',
  },
  userMessage: {
    justifyContent: 'flex-end',
  },
  doctorMessage: {
    justifyContent: 'flex-start',
  },
  messageBubble: {
    maxWidth: '75%',
    borderRadius: 18,
    padding: 12,
  },
  userBubble: {
    backgroundColor: '#2C64F5',
  },
  doctorBubble: {
    backgroundColor: '#F5F5F5',
  },
  messageText: {
    fontSize: 16,
    color: '#333',
    lineHeight: 22,
  },
  messageTimestamp: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E8E8E8',
  },
  input: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    maxHeight: 100,
    marginRight: 8,
  },
  sendButton: {
    backgroundColor: '#2C64F5',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  sendButtonText: {
    color: 'white',
    fontWeight: '600',
  },
});