import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../App';

type MedicationsScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Medications'>;
type MedicationsScreenRouteProp = RouteProp<RootStackParamList, 'Medications'>;

interface MedicationsScreenProps {
  navigation: MedicationsScreenNavigationProp;
  route: MedicationsScreenRouteProp;
}

// Sample medication data for UI demonstration
const SAMPLE_MEDICATIONS = [
  {
    id: 1,
    name: 'Lisinopril',
    dosage: '10mg',
    frequency: 'Once daily',
    startDate: '2024-10-15',
    endDate: '',
    instructions: 'Take in the morning with food',
    remainingDoses: 25,
    status: 'active'
  },
  {
    id: 2,
    name: 'Metformin',
    dosage: '500mg',
    frequency: 'Twice daily',
    startDate: '2024-09-01',
    endDate: '',
    instructions: 'Take with meals',
    remainingDoses: 42,
    status: 'active'
  },
  {
    id: 3,
    name: 'Amoxicillin',
    dosage: '250mg',
    frequency: 'Every 8 hours',
    startDate: '2024-11-05',
    endDate: '2024-11-12',
    instructions: 'Complete full course of antibiotics',
    remainingDoses: 9,
    status: 'active'
  },
  {
    id: 4,
    name: 'Prednisone',
    dosage: '20mg',
    frequency: 'Once daily',
    startDate: '2024-08-10',
    endDate: '2024-09-10',
    instructions: 'Take with food, taper as directed',
    remainingDoses: 0,
    status: 'completed'
  }
];

export default function MedicationsScreen({ route }: MedicationsScreenProps) {
  const { userId } = route.params;
  const [loading] = useState(false);
  const [activeTab, setActiveTab] = useState('active');

  // Filter medications by status
  const filteredMedications = SAMPLE_MEDICATIONS.filter(
    medication => medication.status === activeTab
  );

  // Get the appropriate medication icon based on frequency
  const getMedicationIcon = (frequency: string) => {
    if (frequency.includes('Once')) return '💊';
    if (frequency.includes('Twice')) return '💊💊';
    if (frequency.includes('8 hours')) return '⏰';
    return '💊';
  };

  // Format date to more readable format
  const formatDate = (dateString: string) => {
    if (!dateString) return 'Ongoing';
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2C64F5" />
        <Text style={styles.loadingText}>Loading medications...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'active' && styles.activeTab
          ]}
          onPress={() => setActiveTab('active')}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'active' && styles.activeTabText
          ]}>
            Active
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'completed' && styles.activeTab
          ]}
          onPress={() => setActiveTab('completed')}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'completed' && styles.activeTabText
          ]}>
            Completed
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.headerContainer}>
        <Text style={styles.headerTitle}>
          {activeTab === 'active' ? 'Current Medications' : 'Past Medications'}
        </Text>
        <TouchableOpacity style={styles.addButton}>
          <Text style={styles.addButtonText}>Add New</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredMedications}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.medicationCard}>
            <View style={styles.medicationHeader}>
              <View style={styles.iconContainer}>
                <Text style={styles.medicationIcon}>{getMedicationIcon(item.frequency)}</Text>
              </View>
              <View style={styles.medicationInfo}>
                <Text style={styles.medicationName}>{item.name}</Text>
                <Text style={styles.medicationDosage}>{item.dosage} • {item.frequency}</Text>
              </View>
            </View>
            
            <View style={styles.divider} />
            
            <View style={styles.detailsContainer}>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Start Date:</Text>
                <Text style={styles.detailValue}>{formatDate(item.startDate)}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>End Date:</Text>
                <Text style={styles.detailValue}>{formatDate(item.endDate)}</Text>
              </View>
              
              {item.instructions && (
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Instructions:</Text>
                  <Text style={styles.detailValue}>{item.instructions}</Text>
                </View>
              )}
              
              {activeTab === 'active' && (
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Remaining:</Text>
                  <Text style={styles.detailValue}>
                    {item.remainingDoses} doses
                  </Text>
                </View>
              )}
            </View>
            
            {activeTab === 'active' && (
              <View style={styles.actionContainer}>
                <TouchableOpacity style={styles.takenButton}>
                  <Text style={styles.takenButtonText}>Log Taken Dose</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.refillButton}>
                  <Text style={styles.refillButtonText}>Request Refill</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>
              {activeTab === 'active' 
                ? 'No active medications. Add a new medication to start tracking.'
                : 'No completed medications found.'}
            </Text>
          </View>
        }
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#2C64F5',
  },
  tabText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  activeTabText: {
    color: '#2C64F5',
    fontWeight: '600',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  addButton: {
    backgroundColor: '#2C64F5',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  addButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
  listContainer: {
    padding: 16,
    paddingBottom: 24,
  },
  medicationCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  medicationHeader: {
    flexDirection: 'row',
    padding: 16,
    alignItems: 'center',
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E6F7FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  medicationIcon: {
    fontSize: 24,
  },
  medicationInfo: {
    flex: 1,
  },
  medicationName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  medicationDosage: {
    fontSize: 14,
    color: '#666',
  },
  divider: {
    height: 1,
    backgroundColor: '#E8E8E8',
  },
  detailsContainer: {
    padding: 16,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    width: 100,
  },
  detailValue: {
    fontSize: 14,
    color: '#333',
    flex: 1,
  },
  actionContainer: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#E8E8E8',
    padding: 12,
  },
  takenButton: {
    flex: 1,
    backgroundColor: '#2C64F5',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 8,
  },
  takenButtonText: {
    color: 'white',
    fontWeight: '500',
  },
  refillButton: {
    flex: 1,
    backgroundColor: '#E6F7FF',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  refillButtonText: {
    color: '#2C64F5',
    fontWeight: '500',
  },
  emptyState: {
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});