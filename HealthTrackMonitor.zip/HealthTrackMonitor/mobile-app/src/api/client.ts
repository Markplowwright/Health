import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { User, Vital, Notification } from '../types';

// Create axios instance
const api = axios.create({
  // Base URL should be updated to your backend URL
  baseURL: 'http://localhost:5000/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  }
});

// Add request interceptor to add auth token
api.interceptors.request.use(
  async (config) => {
    try {
      const userId = await SecureStore.getItemAsync('user_id');
      if (userId) {
        config.headers['User-Id'] = userId;
      }
      return config;
    } catch (error) {
      return Promise.reject(error);
    }
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.error('Response error:', error.response.data);
    } else if (error.request) {
      // The request was made but no response was received
      console.error('Request error:', error.request);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error('Error:', error.message);
    }
    return Promise.reject(error);
  }
);

// API functions

export const login = async (username: string, password: string) => {
  try {
    const response = await api.post('/auth/login', { username, password });
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

export const getUserData = async (userId: number): Promise<User> => {
  try {
    const response = await api.get(`/users/${userId}`);
    return response.data;
  } catch (error) {
    console.error('Get user data error:', error);
    throw error;
  }
};

export const getVitals = async (userId: number): Promise<Vital[]> => {
  try {
    const response = await api.get(`/users/${userId}/vitals`);
    return response.data;
  } catch (error) {
    console.error('Get vitals error:', error);
    throw error;
  }
};

export const getLatestVitals = async (userId: number): Promise<Record<string, Vital>> => {
  try {
    const response = await api.get(`/users/${userId}/vitals/latest`);
    return response.data;
  } catch (error) {
    console.error('Get latest vitals error:', error);
    throw error;
  }
};

export const addVital = async (vital: {
  userId: number;
  type: string;
  value: number;
  unit: string;
  notes?: string;
}): Promise<Vital> => {
  try {
    const response = await api.post('/vitals', vital);
    return response.data;
  } catch (error) {
    console.error('Add vital error:', error);
    throw error;
  }
};

export const getNotifications = async (userId: number): Promise<Notification[]> => {
  try {
    const response = await api.get(`/users/${userId}/notifications`);
    return response.data;
  } catch (error) {
    console.error('Get notifications error:', error);
    throw error;
  }
};

export const markNotificationAsRead = async (notificationId: number): Promise<boolean> => {
  try {
    const response = await api.patch(`/notifications/${notificationId}/read`, {});
    return response.data.success;
  } catch (error) {
    console.error('Mark notification as read error:', error);
    throw error;
  }
};

export const markAllNotificationsAsRead = async (userId: number): Promise<boolean> => {
  try {
    const response = await api.patch(`/users/${userId}/notifications/read-all`, {});
    return response.data.success;
  } catch (error) {
    console.error('Mark all notifications as read error:', error);
    throw error;
  }
};