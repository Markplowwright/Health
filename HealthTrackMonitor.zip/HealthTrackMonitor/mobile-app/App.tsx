import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StyleSheet } from 'react-native';

// Import all screens
import LoginScreen from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import VitalsScreen from './src/screens/VitalsScreen';
import MedicationsScreen from './src/screens/MedicationsScreen';
import AppointmentsScreen from './src/screens/AppointmentsScreen';
import MessagesScreen from './src/screens/MessagesScreen';
import ProfileScreen from './src/screens/ProfileScreen';

// Define the types for the stack navigator
export type RootStackParamList = {
  Login: undefined;
  Dashboard: { userId: number };
  Vitals: { userId: number };
  Medications: { userId: number };
  Appointments: { userId: number };
  Messages: { userId: number };
  Profile: { userId: number };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="auto" />
      <NavigationContainer>
        <Stack.Navigator 
          initialRouteName="Login"
          screenOptions={{
            headerStyle: {
              backgroundColor: '#2C64F5',
            },
            headerTintColor: '#fff',
            headerTitleStyle: {
              fontWeight: 'bold',
            },
          }}
        >
          <Stack.Screen 
            name="Login" 
            component={LoginScreen} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="Dashboard" 
            component={DashboardScreen} 
            options={{ title: 'Dashboard' }} 
          />
          <Stack.Screen 
            name="Vitals" 
            component={VitalsScreen} 
            options={{ title: 'Health Vitals' }} 
          />
          <Stack.Screen 
            name="Medications" 
            component={MedicationsScreen} 
            options={{ title: 'Medications' }} 
          />
          <Stack.Screen 
            name="Appointments" 
            component={AppointmentsScreen} 
            options={{ title: 'Appointments' }} 
          />
          <Stack.Screen 
            name="Messages" 
            component={MessagesScreen} 
            options={{ title: 'Messages' }} 
          />
          <Stack.Screen 
            name="Profile" 
            component={ProfileScreen} 
            options={{ title: 'Profile' }} 
          />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
});