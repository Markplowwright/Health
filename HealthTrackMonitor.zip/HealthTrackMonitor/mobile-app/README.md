# HealthConnect Mobile App

A React Native mobile application for patient health monitoring, connecting to the HealthConnect web application backend.

## Features

- **Secure Authentication**: Login to access your personal health data
- **Dashboard**: View your latest vital readings and notifications at a glance
- **Vitals Tracking**: Record and monitor your health metrics (heart rate, blood pressure, blood oxygen, temperature)
- **Medications**: Keep track of your medications and dosage schedules
- **Appointments**: Manage your upcoming doctor appointments
- **Messaging**: Communicate directly with your healthcare providers
- **Profile Management**: Update your personal information and preferences

## Prerequisites

- Node.js 16+
- Expo CLI
- Expo Go app for iOS/Android (for running on physical devices)

## Getting Started

1. Clone the repository
2. Navigate to the mobile-app directory
3. Install dependencies:
   ```
   npm install
   ```
4. Start the development server:
   ```
   npm start
   ```
5. Scan the QR code with the Expo Go app on your device, or run on an emulator/simulator

## Architecture

The mobile app is built with:

- **React Native**: Core framework for building the mobile UI
- **Expo**: Toolchain for simplifying React Native development
- **React Navigation**: Navigation and routing
- **Axios**: HTTP client for API requests
- **Expo Secure Store**: Secure storage for sensitive data

## API Connection

The app connects to the same backend as the HealthConnect web application. You'll need to:

1. Make sure the backend server is running
2. Update the API base URL in `src/api/client.ts` to point to your server

## Development Notes

- For login, use the same credentials as the web app (default: username: "patient", password: "password123")
- The app uses a responsive design that works on both phones and tablets
- App settings and preferences are saved locally using Expo Secure Store