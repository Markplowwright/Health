import { users, type User, type InsertUser, vitals, type Vital, type InsertVital, notifications, type Notification, type InsertNotification, vitalHistory, type VitalHistory, type InsertVitalHistory } from "@shared/schema";

export interface IStorage {
  // User related methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Vital related methods
  createVital(vital: InsertVital): Promise<Vital>;
  getVitals(userId: number, limit?: number): Promise<Vital[]>;
  getVitalsByType(userId: number, type: string, limit?: number): Promise<Vital[]>;
  getLatestVitalsByType(userId: number): Promise<Record<string, Vital>>;
  
  // Notification related methods
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotifications(userId: number, limit?: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<boolean>;
  markAllNotificationsAsRead(userId: number): Promise<boolean>;
  
  // Vital history related methods
  getVitalHistory(userId: number, type: string): Promise<VitalHistory | undefined>;
  updateVitalHistory(userId: number, type: string, data: any): Promise<VitalHistory>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private vitals: Map<number, Vital>;
  private notifications: Map<number, Notification>;
  private vitalHistories: Map<string, VitalHistory>;
  private userId: number;
  private vitalId: number;
  private notificationId: number;
  private vitalHistoryId: number;

  constructor() {
    this.users = new Map();
    this.vitals = new Map();
    this.notifications = new Map();
    this.vitalHistories = new Map();
    this.userId = 1;
    this.vitalId = 1;
    this.notificationId = 1;
    this.vitalHistoryId = 1;
    
    // Add a default user for testing
    this.createUser({
      username: "patient",
      password: "password123",
      fullName: "Sarah Johnson",
      email: "sarah@example.com",
      phone: "+1234567890",
      dateOfBirth: "1985-06-15",
      careTeam: "Dr. Michael Chen",
      monitoringSince: "June 15, 2023",
      nextCheckIn: "Today, 4:30 PM",
    });
    
    // Add sample initial vital history data for the default user
    this.initializeDefaultUserData(1);
  }

  private initializeDefaultUserData(userId: number) {
    // Initialize with empty data for charts
    const types = ["Blood Pressure", "Heart Rate", "Blood Oxygen", "Temperature"];
    const units = ["mmHg", "bpm", "%", "°F"];
    const initialValues = ["120/80", "72", "98", "98.6"];
    
    types.forEach((type, index) => {
      // Create initial history data
      this.updateVitalHistory(userId, type, []);
      
      // Create initial latest reading
      this.createVital({
        userId,
        type,
        value: initialValues[index],
        unit: units[index],
        timestamp: new Date(),
        notes: "",
        status: "normal"
      });
      
      // Create initial notifications
      if (index === 0) {
        this.createNotification({
          userId,
          title: "Time to take your medication",
          message: "Lisinopril 10mg - 1 tablet",
          type: "medication",
          isRead: false,
          timestamp: new Date(Date.now() - 30 * 60 * 1000) // 30 minutes ago
        });
      } else if (index === 1) {
        this.createNotification({
          userId,
          title: "Upcoming appointment reminder",
          message: "Dr. Chen - Cardiology Follow-up",
          type: "appointment",
          isRead: false,
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
        });
      } else if (index === 2) {
        this.createNotification({
          userId,
          title: "Blood pressure reading alert",
          message: "Higher than your normal range",
          type: "alert",
          isRead: false,
          timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
        });
      } else if (index === 3) {
        this.createNotification({
          userId,
          title: "New message from Dr. Chen",
          message: "Your test results look good, keep up...",
          type: "message",
          isRead: false,
          timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
        });
      }
    });
  }

  // User related methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Vital related methods
  async createVital(insertVital: InsertVital): Promise<Vital> {
    const id = this.vitalId++;
    const vital: Vital = { ...insertVital, id };
    this.vitals.set(id, vital);
    
    // Update vital history when a new vital is added
    const history = await this.getVitalHistory(insertVital.userId, insertVital.type);
    if (history) {
      const data = Array.isArray(history.data) ? history.data : [];
      data.push({
        value: insertVital.value,
        timestamp: insertVital.timestamp,
        status: insertVital.status
      });
      
      // Keep only the last 30 entries
      if (data.length > 30) {
        data.shift();
      }
      
      await this.updateVitalHistory(insertVital.userId, insertVital.type, data);
    }
    
    return vital;
  }

  async getVitals(userId: number, limit = 100): Promise<Vital[]> {
    const userVitals = Array.from(this.vitals.values())
      .filter(vital => vital.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return limit ? userVitals.slice(0, limit) : userVitals;
  }

  async getVitalsByType(userId: number, type: string, limit = 100): Promise<Vital[]> {
    const userVitals = Array.from(this.vitals.values())
      .filter(vital => vital.userId === userId && vital.type === type)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return limit ? userVitals.slice(0, limit) : userVitals;
  }

  async getLatestVitalsByType(userId: number): Promise<Record<string, Vital>> {
    const vitals = await this.getVitals(userId);
    const latestByType: Record<string, Vital> = {};
    
    for (const vital of vitals) {
      if (!latestByType[vital.type] || 
          new Date(vital.timestamp) > new Date(latestByType[vital.type].timestamp)) {
        latestByType[vital.type] = vital;
      }
    }
    
    return latestByType;
  }

  // Notification related methods
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationId++;
    const notification: Notification = { ...insertNotification, id };
    this.notifications.set(id, notification);
    return notification;
  }

  async getNotifications(userId: number, limit = 100): Promise<Notification[]> {
    const userNotifications = Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return limit ? userNotifications.slice(0, limit) : userNotifications;
  }

  async markNotificationAsRead(id: number): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;
    
    notification.isRead = true;
    this.notifications.set(id, notification);
    return true;
  }

  async markAllNotificationsAsRead(userId: number): Promise<boolean> {
    const userNotifications = Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId);
    
    for (const notification of userNotifications) {
      notification.isRead = true;
      this.notifications.set(notification.id, notification);
    }
    
    return true;
  }

  // Vital history related methods
  async getVitalHistory(userId: number, type: string): Promise<VitalHistory | undefined> {
    const key = `${userId}-${type}`;
    return this.vitalHistories.get(key);
  }

  async updateVitalHistory(userId: number, type: string, data: any): Promise<VitalHistory> {
    const key = `${userId}-${type}`;
    const existing = this.vitalHistories.get(key);
    
    if (existing) {
      const updated: VitalHistory = {
        ...existing,
        data,
        updatedAt: new Date()
      };
      this.vitalHistories.set(key, updated);
      return updated;
    } else {
      const id = this.vitalHistoryId++;
      const newHistory: VitalHistory = {
        id,
        userId,
        type,
        data,
        updatedAt: new Date()
      };
      this.vitalHistories.set(key, newHistory);
      return newHistory;
    }
  }
}

export const storage = new MemStorage();
