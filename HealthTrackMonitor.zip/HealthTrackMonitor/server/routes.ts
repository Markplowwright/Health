import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { insertVitalSchema, insertNotificationSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

interface Client {
  userId: number;
  socket: WebSocket;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store connected clients
  const clients: Client[] = [];
  
  wss.on('connection', (socket) => {
    let userId: number | null = null;
    
    socket.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle authentication message
        if (data.type === 'auth' && data.userId) {
          userId = parseInt(data.userId);
          // Store client connection with userId
          clients.push({ userId, socket });
          
          // Send initial data to client after authentication
          const user = await storage.getUser(userId);
          const latestVitals = await storage.getLatestVitalsByType(userId);
          const vitalHistoryData: Record<string, any> = {};
          
          // Get history for all vital types
          for (const type in latestVitals) {
            const history = await storage.getVitalHistory(userId, type);
            if (history) {
              vitalHistoryData[type] = history.data;
            }
          }
          
          // Send initial data to client
          socket.send(JSON.stringify({
            type: 'init',
            user,
            latestVitals,
            vitalHistoryData
          }));
          
          // Also send notifications
          const notifications = await storage.getNotifications(userId, 4);
          socket.send(JSON.stringify({
            type: 'notifications',
            notifications
          }));
        }
        
        // Handle vital reading submission
        if (data.type === 'vital' && userId) {
          const vitalData = {
            userId,
            type: data.vitalType,
            value: data.value,
            unit: data.unit,
            timestamp: new Date(data.timestamp || Date.now()),
            notes: data.notes || '',
            status: data.status || 'normal'
          };
          
          try {
            const validatedData = insertVitalSchema.parse(vitalData);
            const newVital = await storage.createVital(validatedData);
            
            // Get updated vital history
            const history = await storage.getVitalHistory(userId, newVital.type);
            
            // Broadcast to all clients with the same userId
            broadcastToUser(userId, {
              type: 'vitalUpdate',
              vital: newVital,
              history: history?.data || []
            });
            
            // Send success response
            socket.send(JSON.stringify({
              type: 'success',
              message: 'Vital reading saved successfully'
            }));
          } catch (err) {
            if (err instanceof ZodError) {
              const validationError = fromZodError(err);
              socket.send(JSON.stringify({
                type: 'error',
                message: validationError.message
              }));
            } else {
              socket.send(JSON.stringify({
                type: 'error',
                message: 'Failed to save vital reading'
              }));
            }
          }
        }
      } catch (err) {
        console.error('Error processing message:', err);
        socket.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });
    
    // Handle disconnection
    socket.on('close', () => {
      if (userId) {
        const index = clients.findIndex(client => client.userId === userId && client.socket === socket);
        if (index !== -1) {
          clients.splice(index, 1);
        }
      }
    });
  });
  
  // Function to broadcast messages to all clients with the same userId
  function broadcastToUser(userId: number, message: any) {
    const userClients = clients.filter(client => client.userId === userId);
    const messageStr = JSON.stringify(message);
    
    userClients.forEach(client => {
      if (client.socket.readyState === WebSocket.OPEN) {
        client.socket.send(messageStr);
      }
    });
  }
  
  // Authentication routes
  app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
    
    const user = await storage.getUserByUsername(username);
    
    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }
    
    // Return user data without password
    const { password: _, ...userData } = user;
    return res.status(200).json(userData);
  });
  
  // User routes
  app.get('/api/users/:id', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Return user data without password
    const { password, ...userData } = user;
    return res.status(200).json(userData);
  });
  
  // Vital routes
  app.get('/api/users/:id/vitals', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const vitals = await storage.getVitals(userId);
    return res.status(200).json(vitals);
  });
  
  app.get('/api/users/:id/vitals/latest', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const latestVitals = await storage.getLatestVitalsByType(userId);
    return res.status(200).json(latestVitals);
  });
  
  app.post('/api/users/:id/vitals', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const vitalData = {
      userId,
      ...req.body,
      timestamp: new Date(req.body.timestamp || Date.now())
    };
    
    try {
      const validatedData = insertVitalSchema.parse(vitalData);
      const newVital = await storage.createVital(validatedData);
      
      // Broadcast update to connected clients
      const history = await storage.getVitalHistory(userId, newVital.type);
      
      broadcastToUser(userId, {
        type: 'vitalUpdate',
        vital: newVital,
        history: history?.data || []
      });
      
      return res.status(201).json(newVital);
    } catch (err) {
      if (err instanceof ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: 'Failed to save vital reading' });
    }
  });
  
  // Notification routes
  app.get('/api/users/:id/notifications', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const notifications = await storage.getNotifications(userId, limit);
    return res.status(200).json(notifications);
  });
  
  app.post('/api/users/:id/notifications', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const notificationData = {
      userId,
      ...req.body,
      timestamp: new Date(req.body.timestamp || Date.now())
    };
    
    try {
      const validatedData = insertNotificationSchema.parse(notificationData);
      const newNotification = await storage.createNotification(validatedData);
      
      // Broadcast new notification to connected clients
      broadcastToUser(userId, {
        type: 'newNotification',
        notification: newNotification
      });
      
      return res.status(201).json(newNotification);
    } catch (err) {
      if (err instanceof ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: 'Failed to create notification' });
    }
  });
  
  app.put('/api/users/:userId/notifications/:id/read', async (req, res) => {
    const userId = parseInt(req.params.userId);
    const notificationId = parseInt(req.params.id);
    
    if (isNaN(userId) || isNaN(notificationId)) {
      return res.status(400).json({ message: 'Invalid user ID or notification ID' });
    }
    
    const success = await storage.markNotificationAsRead(notificationId);
    
    if (!success) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    
    // Broadcast notification update
    const notifications = await storage.getNotifications(userId, 4);
    broadcastToUser(userId, {
      type: 'notifications',
      notifications
    });
    
    return res.status(200).json({ success: true });
  });
  
  app.put('/api/users/:id/notifications/read-all', async (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const success = await storage.markAllNotificationsAsRead(userId);
    
    if (success) {
      // Broadcast notification update
      const notifications = await storage.getNotifications(userId, 4);
      broadcastToUser(userId, {
        type: 'notifications',
        notifications
      });
      
      return res.status(200).json({ success: true });
    }
    
    return res.status(500).json({ message: 'Failed to mark notifications as read' });
  });
  
  // Vital history routes
  app.get('/api/users/:id/vital-history/:type', async (req, res) => {
    const userId = parseInt(req.params.id);
    const type = req.params.type;
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }
    
    const history = await storage.getVitalHistory(userId, type);
    
    if (!history) {
      return res.status(404).json({ message: 'History not found' });
    }
    
    return res.status(200).json(history);
  });

  return httpServer;
}
