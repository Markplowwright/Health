import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface ProfileProps {
  userId: number;
}

export default function Profile({ userId }: ProfileProps) {
  const { data: user, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}`],
  });
  
  if (isLoading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-12 bg-gray-200 rounded-md w-1/3"></div>
        <div className="h-64 bg-gray-200 rounded-md"></div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-2">User Not Found</h1>
        <p className="text-neutral-500">The requested profile could not be loaded.</p>
      </div>
    );
  }
  
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 font-montserrat">Patient Profile</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="pt-6 text-center">
              <Avatar className="h-24 w-24 mx-auto mb-4">
                <AvatarImage src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&h=200&q=80" alt={user.fullName} />
                <AvatarFallback className="text-2xl">{user.fullName?.charAt(0) || 'U'}</AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-semibold mb-1">{user.fullName}</h2>
              <p className="text-neutral-500">Patient ID: {user.id}</p>
              
              <div className="mt-6 text-left">
                <h3 className="font-medium mb-2 text-neutral-700">Care Team</h3>
                <p className="text-neutral-600 mb-4">{user.careTeam || 'No care team assigned'}</p>
                
                <h3 className="font-medium mb-2 text-neutral-700">Monitoring Since</h3>
                <p className="text-neutral-600">{user.monitoringSince || 'Not available'}</p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-6">
                <div>
                  <dt className="text-sm font-medium text-neutral-500">Full Name</dt>
                  <dd className="mt-1 text-neutral-900">{user.fullName}</dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-neutral-500">Username</dt>
                  <dd className="mt-1 text-neutral-900">{user.username}</dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-neutral-500">Email</dt>
                  <dd className="mt-1 text-neutral-900">{user.email}</dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-neutral-500">Phone</dt>
                  <dd className="mt-1 text-neutral-900">{user.phone || 'Not provided'}</dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-neutral-500">Date of Birth</dt>
                  <dd className="mt-1 text-neutral-900">{user.dateOfBirth || 'Not provided'}</dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-neutral-500">Next Check-in</dt>
                  <dd className="mt-1 text-neutral-900">{user.nextCheckIn || 'Not scheduled'}</dd>
                </div>
              </dl>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Data Privacy & Security</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600 mb-4">
                Your health data is encrypted and securely transmitted to your healthcare provider.
                Only authorized members of your care team have access to your information.
              </p>
              
              <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
                <h3 className="text-blue-800 font-medium mb-2 flex items-center">
                  <span className="material-icons mr-1 text-blue-600 text-sm">info</span>
                  Data Sharing Consent
                </h3>
                <p className="text-blue-700 text-sm">
                  You have provided consent for your health data to be shared with your care team.
                  You can revoke this consent at any time from the privacy settings.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
