import WelcomePanel from "@/components/dashboard/welcome-panel";
import VitalsOverview from "@/components/dashboard/vitals-overview";
import DataEntryPanel from "@/components/dashboard/data-entry-panel";
import NotificationsPanel from "@/components/dashboard/notifications-panel";

interface DashboardProps {
  userId: number;
}

export default function Dashboard({ userId }: DashboardProps) {
  return (
    <>
      <WelcomePanel userId={userId} />
      <VitalsOverview userId={userId} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <DataEntryPanel userId={userId} />
        <NotificationsPanel userId={userId} />
      </div>
    </>
  );
}
