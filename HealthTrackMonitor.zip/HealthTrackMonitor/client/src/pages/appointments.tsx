import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface AppointmentsProps {
  userId: number;
}

export default function Appointments({ userId }: AppointmentsProps) {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 font-montserrat">Appointments</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Upcoming Appointments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <span className="material-icons text-6xl text-neutral-300 mb-4">event</span>
              <h3 className="text-lg font-medium mb-2">No upcoming appointments</h3>
              <p className="text-neutral-500">
                Your scheduled appointments will appear here.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
