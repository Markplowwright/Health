import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface MessagesProps {
  userId: number;
}

export default function Messages({ userId }: MessagesProps) {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 font-montserrat">Messages</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Your Messages</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <span className="material-icons text-6xl text-neutral-300 mb-4">chat</span>
              <h3 className="text-lg font-medium mb-2">No messages yet</h3>
              <p className="text-neutral-500">
                Messages from your healthcare team will appear here.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
