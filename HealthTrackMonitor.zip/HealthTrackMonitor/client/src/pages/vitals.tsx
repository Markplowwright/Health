import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { formatTimeAgo } from "@/lib/utils";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface VitalsProps {
  userId: number;
}

export default function Vitals({ userId }: VitalsProps) {
  const { data: allVitals, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}/vitals`],
  });
  
  const vitalTypes = ["Blood Pressure", "Heart Rate", "Blood Oxygen", "Temperature"];
  
  if (isLoading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-12 bg-gray-200 rounded-md w-1/3"></div>
        <div className="h-64 bg-gray-200 rounded-md"></div>
      </div>
    );
  }
  
  const groupedVitals = vitalTypes.reduce((acc, type) => {
    acc[type] = allVitals?.filter(vital => vital.type === type) || [];
    return acc;
  }, {} as Record<string, any[]>);
  
  // Format data for charts
  const chartData = Object.keys(groupedVitals).reduce((acc, type) => {
    const data = groupedVitals[type].map(vital => {
      let value = vital.value;
      if (type === "Blood Pressure") {
        const [systolic] = vital.value.split("/");
        value = parseInt(systolic);
      }
      return {
        time: new Date(vital.timestamp).toLocaleTimeString(),
        date: new Date(vital.timestamp).toLocaleDateString(),
        value: typeof value === 'string' ? parseFloat(value) : value,
        original: vital.value
      };
    });
    acc[type] = data.reverse().slice(0, 20); // Get last 20 readings in chronological order
    return acc;
  }, {} as Record<string, any[]>);
  
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 font-montserrat">Vitals History</h1>
      
      <Tabs defaultValue="Blood Pressure" className="w-full">
        <TabsList className="mb-6">
          {vitalTypes.map(type => (
            <TabsTrigger key={type} value={type} className="px-4 py-2">
              {type}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {vitalTypes.map(type => (
          <TabsContent key={type} value={type}>
            <div className="grid grid-cols-1 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>{type} History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={chartData[type]}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value, name) => {
                            if (type === "Blood Pressure") {
                              const entry = chartData[type].find(item => item.value === value);
                              return [entry?.original || value, name];
                            }
                            return [value, name];
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="value" 
                          stroke="#1976D2" 
                          activeDot={{ r: 8 }} 
                          name={type}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Recent {type} Readings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="py-2 px-4 text-left">Reading</th>
                          <th className="py-2 px-4 text-left">Date & Time</th>
                          <th className="py-2 px-4 text-left">Status</th>
                          <th className="py-2 px-4 text-left">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {groupedVitals[type].length > 0 ? (
                          groupedVitals[type].map((vital, index) => (
                            <tr key={index} className="border-b hover:bg-gray-50">
                              <td className="py-3 px-4 font-medium">
                                {vital.value} {vital.unit}
                              </td>
                              <td className="py-3 px-4 text-neutral-600">
                                {new Date(vital.timestamp).toLocaleString()}
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-1 rounded-full text-xs ${
                                  vital.status === 'normal' ? 'bg-green-100 text-green-800' :
                                  vital.status === 'warning' ? 'bg-amber-100 text-amber-800' :
                                  'bg-red-100 text-red-800'
                                }`}>
                                  {vital.status || 'Normal'}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-neutral-600">
                                {vital.notes || '-'}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="py-4 text-center text-neutral-500">
                              No readings available
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
