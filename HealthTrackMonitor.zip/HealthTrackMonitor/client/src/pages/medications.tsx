import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface MedicationsProps {
  userId: number;
}

export default function Medications({ userId }: MedicationsProps) {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 font-montserrat">Medications</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Your Medications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <span className="material-icons text-6xl text-neutral-300 mb-4">medication</span>
              <h3 className="text-lg font-medium mb-2">No medications found</h3>
              <p className="text-neutral-500">
                Your medications will appear here once your doctor prescribes them.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
