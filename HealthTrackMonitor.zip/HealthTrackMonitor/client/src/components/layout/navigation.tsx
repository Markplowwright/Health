import { Link } from "wouter";
import { cn } from "@/lib/utils";

interface NavItemProps {
  path: string;
  label: string;
  icon: string;
  currentPath: string;
}

function NavItem({ path, label, icon, currentPath }: NavItemProps) {
  const isActive = path === "/" ? currentPath === path : currentPath.startsWith(path);
  
  return (
    <Link href={path} 
      className={cn(
        "px-4 py-3 text-center whitespace-nowrap text-sm font-medium flex flex-col items-center",
        isActive
          ? "border-b-3 border-primary text-primary"
          : "text-neutral-600 hover:text-primary hover:bg-neutral-50"
      )}
    >
      <span className="material-icons text-sm block mx-auto mb-1">{icon}</span>
      {label}
    </Link>
  );
}

interface NavigationProps {
  currentPath: string;
}

export default function Navigation({ currentPath }: NavigationProps) {
  const navItems = [
    { path: "/", label: "Dashboard", icon: "dashboard" },
    { path: "/vitals", label: "Vitals", icon: "favorite" },
    { path: "/medications", label: "Medications", icon: "medication" },
    { path: "/appointments", label: "Appointments", icon: "event_note" },
    { path: "/messages", label: "Messages", icon: "chat" },
    { path: "/profile", label: "Profile", icon: "person" }
  ];

  return (
    <nav className="bg-white border-b border-neutral-200">
      <div className="container mx-auto px-4">
        <div className="flex overflow-x-auto no-scrollbar">
          {navItems.map((item) => (
            <NavItem
              key={item.path}
              path={item.path}
              label={item.label}
              icon={item.icon}
              currentPath={currentPath}
            />
          ))}
        </div>
      </div>
    </nav>
  );
}
