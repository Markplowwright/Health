import { useState } from "react";
import { Bell, Search } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/lib/websocket";
import { InstallPWAButton } from "@/components/pwa/install-button";
import { OfflineIndicator } from "@/components/pwa/offline-indicator";
import { User } from "@shared/schema";

interface HeaderProps {
  userId: number;
}

export default function Header({ userId }: HeaderProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    refetchInterval: false,
  });

  const { connected } = useWebSocket();
  const fullName = user?.fullName || "User";

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <span className="material-icons text-primary text-3xl">health_and_safety</span>
          <h1 className="font-bold text-xl text-primary font-montserrat">HealthConnect</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Offline status indicator */}
          <OfflineIndicator className="mr-2" />
          
          {/* PWA install button */}
          <InstallPWAButton className="mr-2" />
          
          <div className="relative hidden md:block">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center">
              <Search className="h-4 w-4 text-neutral-600" />
            </span>
            <Input 
              type="text" 
              placeholder="Search" 
              className="pl-10 pr-4 py-2 rounded-full bg-neutral-100 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          
          <button 
            className="relative p-2 rounded-full hover:bg-neutral-100"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <Bell className="h-5 w-5 text-neutral-600" />
            <Badge className="absolute top-1 right-1 h-2 w-2 p-0 bg-accent" />
          </button>
          
          <div className="flex items-center">
            <Avatar className="h-8 w-8">
              <AvatarImage src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80" alt={fullName} />
              <AvatarFallback>{fullName.charAt(0)}</AvatarFallback>
            </Avatar>
            <span className="ml-2 text-sm font-medium hidden md:inline">
              {fullName}
            </span>
            {connected && (
              <Badge variant="outline" className="ml-2 bg-green-50 text-green-600 border-green-200 text-xs">
                <span className="h-2 w-2 bg-green-500 rounded-full mr-1 animate-pulse"></span>
                Connected
              </Badge>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
