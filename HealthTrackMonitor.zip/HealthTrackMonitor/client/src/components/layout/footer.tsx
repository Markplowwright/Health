import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-neutral-200 mt-6">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <span className="material-icons text-primary mr-2">health_and_safety</span>
            <span className="font-semibold text-primary font-montserrat">HealthConnect</span>
          </div>
          
          <div className="flex space-x-6 text-sm text-neutral-600">
            <Link href="/privacy">
              <a className="hover:text-primary">Privacy Policy</a>
            </Link>
            <Link href="/terms">
              <a className="hover:text-primary">Terms of Service</a>
            </Link>
            <Link href="/support">
              <a className="hover:text-primary">Contact Support</a>
            </Link>
            <Link href="/about">
              <a className="hover:text-primary">About</a>
            </Link>
          </div>
        </div>
        
        <div className="mt-4 text-xs text-neutral-500 text-center md:text-left">
          <p>© 2023 HealthConnect. All rights reserved. Patient data is encrypted and protected.</p>
        </div>
      </div>
    </footer>
  );
}
