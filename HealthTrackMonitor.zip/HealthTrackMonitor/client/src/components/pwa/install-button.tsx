import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { checkIfInstallable } from '@/lib/pwa';
import { Download } from 'lucide-react';

interface InstallPWAButtonProps {
  className?: string;
}

export function InstallPWAButton({ className }: InstallPWAButtonProps) {
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  const [isInstalling, setIsInstalling] = useState<boolean>(false);
  const pwaUtils = checkIfInstallable();

  useEffect(() => {
    // Check if app is already installable
    setIsInstallable(pwaUtils.isAppInstallable());

    // Listen for installable event
    const handleInstallable = (e: CustomEvent) => {
      setIsInstallable(e.detail);
    };

    // Listen for installed event
    const handleInstalled = () => {
      setIsInstallable(false);
    };

    // Add event listeners
    window.addEventListener('pwainstallable', handleInstallable as EventListener);
    window.addEventListener('pwainstalled', handleInstalled);

    // Cleanup
    return () => {
      window.removeEventListener('pwainstallable', handleInstallable as EventListener);
      window.removeEventListener('pwainstalled', handleInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      const result = await pwaUtils.promptInstall();
      if (result) {
        console.log('App installed successfully');
      } else {
        console.log('App installation declined');
      }
    } catch (error) {
      console.error('Error installing app:', error);
    } finally {
      setIsInstalling(false);
    }
  };

  if (!isInstallable) {
    return null;
  }

  return (
    <Button 
      className={className}
      variant="outline" 
      size="sm"
      onClick={handleInstallClick}
      disabled={isInstalling}
    >
      <Download className="mr-2 h-4 w-4" />
      {isInstalling ? 'Installing...' : 'Install App'}
    </Button>
  );
}