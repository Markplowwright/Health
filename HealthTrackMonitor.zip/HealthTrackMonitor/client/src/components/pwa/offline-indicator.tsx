import { useState, useEffect } from 'react';
import { useOnlineStatus } from '@/lib/pwa';
import { Wifi, WifiOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface OfflineIndicatorProps {
  className?: string;
}

export function OfflineIndicator({ className }: OfflineIndicatorProps) {
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const onlineStatus = useOnlineStatus();

  useEffect(() => {
    // Set initial status
    setIsOnline(onlineStatus.isOnline());

    // Setup listeners for online/offline events
    const handleOnline = () => {
      setIsOnline(true);
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    const cleanup = onlineStatus.setupListeners(handleOnline, handleOffline);

    // Cleanup function
    return cleanup;
  }, []);

  if (isOnline) {
    return (
      <div className={cn("hidden", className)}>
        <Wifi className="h-4 w-4 text-green-500" />
        <span className="ml-1 text-xs">Online</span>
      </div>
    );
  }

  return (
    <div className={cn("flex items-center px-2 py-1 bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 rounded-md", className)}>
      <WifiOff className="h-4 w-4" />
      <span className="ml-1 text-xs">Offline Mode</span>
    </div>
  );
}