import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/lib/websocket";
import { formatTimeAgo, getNotificationIcon, getNotificationColorClass } from "@/lib/utils";

interface NotificationProps {
  id: number;
  title: string;
  message: string;
  timestamp: string;
  type: string;
  isRead: boolean;
  onRead: (id: number) => void;
}

function Notification({ id, title, message, timestamp, type, isRead, onRead }: NotificationProps) {
  const icon = getNotificationIcon(type);
  const colorClass = getNotificationColorClass(type);
  const formattedTime = formatTimeAgo(timestamp);
  
  return (
    <div className="py-3 first:pt-0 last:pb-0">
      <div className="flex items-start">
        <div className={`h-8 w-8 rounded-full ${colorClass} flex items-center justify-center mr-3 mt-1`}>
          <span className="material-icons text-sm">{icon}</span>
        </div>
        <div className="flex-1">
          <div className="flex justify-between">
            <p className="text-sm font-medium">{title}</p>
            {!isRead && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 px-2 text-xs text-primary"
                onClick={() => onRead(id)}
              >
                Mark read
              </Button>
            )}
          </div>
          <p className="text-xs text-neutral-500 mt-1">{message}</p>
          <div className="flex items-center text-xs text-neutral-500 mt-2">
            <span className="material-icons text-xs mr-1">schedule</span>
            <span>{formattedTime}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

interface NotificationsPanelProps {
  userId: number;
}

export default function NotificationsPanel({ userId }: NotificationsPanelProps) {
  const [notifications, setNotifications] = useState<any[]>([]);
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket();
  
  // Fetch notifications from API
  const { data, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}/notifications?limit=4`],
  });
  
  // Process WebSocket messages
  useEffect(() => {
    if (lastMessage?.type === 'notifications') {
      setNotifications(lastMessage.notifications || []);
    } else if (lastMessage?.type === 'newNotification') {
      setNotifications(prev => [lastMessage.notification, ...prev].slice(0, 4));
    }
  }, [lastMessage]);
  
  // Use API data if WebSocket data is not available yet
  useEffect(() => {
    if (data && notifications.length === 0) {
      setNotifications(data);
    }
  }, [data, notifications.length]);
  
  const handleMarkAsRead = async (id: number) => {
    try {
      await apiRequest('PUT', `/api/users/${userId}/notifications/${id}/read`);
      
      // Update local state
      setNotifications(prev => 
        prev.map(notification => 
          notification.id === id 
            ? { ...notification, isRead: true } 
            : notification
        )
      );
      
      // Invalidate query to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/notifications`] });
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };
  
  const handleMarkAllAsRead = async () => {
    try {
      await apiRequest('PUT', `/api/users/${userId}/notifications/read-all`);
      
      // Update local state
      setNotifications(prev => 
        prev.map(notification => ({ ...notification, isRead: true }))
      );
      
      // Invalidate query to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/notifications`] });
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
    }
  };
  
  if (isLoading && notifications.length === 0) {
    return (
      <div className="lg:col-span-1">
        <Card className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-64 bg-gray-200 rounded-md"></div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="lg:col-span-1">
      <Card className="card hover:shadow-md transition-shadow">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold font-montserrat">Notifications</h2>
            <Button variant="ghost" size="sm" className="text-primary text-sm" onClick={handleMarkAllAsRead}>
              Mark all as read
            </Button>
          </div>
          
          {notifications.length > 0 ? (
            <div className="divide-y divide-neutral-100">
              {notifications.map((notification) => (
                <Notification
                  key={notification.id}
                  id={notification.id}
                  title={notification.title}
                  message={notification.message}
                  timestamp={notification.timestamp}
                  type={notification.type}
                  isRead={notification.isRead}
                  onRead={handleMarkAsRead}
                />
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-neutral-500">
              <span className="material-icons block mx-auto mb-2 text-3xl">notifications_off</span>
              <p>No notifications yet</p>
            </div>
          )}
          
          <div className="mt-4 pt-4 border-t border-neutral-100">
            <Button variant="ghost" className="w-full text-center text-primary text-sm font-medium py-2 hover:bg-primary/5 rounded">
              View All Notifications
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
