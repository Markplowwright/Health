import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { getGreeting } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { 
  Calendar, 
  Upload, 
  MessageSquare, 
  Plus,
  Users,
  CalendarDays 
} from "lucide-react";

interface WelcomePanelProps {
  userId: number;
}

export default function WelcomePanel({ userId }: WelcomePanelProps) {
  const { data: user, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}`],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-6">
              <div className="h-32 animate-pulse bg-gray-200 rounded-md"></div>
            </CardContent>
          </Card>
        </div>
        <div>
          <Card>
            <CardContent className="p-6">
              <div className="h-32 animate-pulse bg-gray-200 rounded-md"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
      <div className="lg:col-span-2">
        <Card className="card hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-xl font-semibold mb-1 font-montserrat">
                  {getGreeting()}, {user?.fullName}
                </h2>
                <p className="text-neutral-600 text-sm">Your health data is being monitored</p>
              </div>
              <span className="bg-green-50 text-green-600 px-3 py-1 rounded-full text-xs font-medium flex items-center">
                <span className="h-2 w-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                Connected
              </span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-neutral-600">Next Check-in</p>
                    <p className="font-semibold mt-1">{user?.nextCheckIn}</p>
                  </div>
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
              </div>
              
              <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-neutral-600">Care Team</p>
                    <p className="font-semibold mt-1">{user?.careTeam}</p>
                  </div>
                  <Users className="h-5 w-5 text-primary" />
                </div>
              </div>
              
              <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-neutral-600">Data Since</p>
                    <p className="font-semibold mt-1">{user?.monitoringSince}</p>
                  </div>
                  <CalendarDays className="h-5 w-5 text-primary" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div>
        <Card className="card hover:shadow-md transition-shadow h-full">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 font-montserrat">Quick Actions</h3>
            
            <div className="space-y-4">
              <Button className="w-full bg-primary hover:bg-primary-dark text-white">
                <Plus className="mr-2 h-4 w-4" />
                Record New Vital
              </Button>
              
              <Button variant="outline" className="w-full border border-neutral-300 hover:bg-neutral-50 text-neutral-800">
                <MessageSquare className="mr-2 h-4 w-4" />
                Message Care Team
              </Button>
              
              <Button variant="outline" className="w-full border border-neutral-300 hover:bg-neutral-50 text-neutral-800">
                <Upload className="mr-2 h-4 w-4" />
                Upload Document
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
