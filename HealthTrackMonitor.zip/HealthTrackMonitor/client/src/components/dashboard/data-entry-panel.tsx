import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/lib/websocket";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel,
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { getVitalUnit } from "@/lib/utils";

const formSchema = z.object({
  vitalType: z.string().min(1, { message: "Please select a reading type" }),
  timestamp: z.string().min(1, { message: "Please select a date and time" }),
  valueSystolic: z.string().optional(),
  valueDiastolic: z.string().optional(),
  value: z.string().optional(),
  notes: z.string().optional(),
});

interface DataEntryPanelProps {
  userId: number;
}

export default function DataEntryPanel({ userId }: DataEntryPanelProps) {
  const { send } = useWebSocket();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      vitalType: "",
      timestamp: new Date().toISOString().slice(0, 16),
      valueSystolic: "",
      valueDiastolic: "",
      value: "",
      notes: "",
    },
  });
  
  const selectedVitalType = form.watch("vitalType");
  const isBloodPressure = selectedVitalType === "Blood Pressure";
  const unit = getVitalUnit(selectedVitalType);
  
  const onSubmit = async (data: z.infer<typeof formSchema>) => {
    try {
      setIsSubmitting(true);
      
      let finalValue = data.value;
      if (isBloodPressure && data.valueSystolic && data.valueDiastolic) {
        finalValue = `${data.valueSystolic}/${data.valueDiastolic}`;
      }
      
      if (!finalValue && !isBloodPressure) {
        toast({
          title: "Validation Error",
          description: "Please enter a value for the reading",
          variant: "destructive",
        });
        return;
      }
      
      if (isBloodPressure && (!data.valueSystolic || !data.valueDiastolic)) {
        toast({
          title: "Validation Error",
          description: "Please enter both systolic and diastolic values",
          variant: "destructive",
        });
        return;
      }
      
      send({
        type: "vital",
        userId,
        vitalType: data.vitalType,
        value: finalValue,
        unit,
        timestamp: new Date(data.timestamp).toISOString(),
        notes: data.notes,
        status: "normal", // Default status, would be calculated based on values in a real app
      });
      
      // Reset form after success (toast will be shown from the WebSocket response)
      form.reset({
        vitalType: "",
        timestamp: new Date().toISOString().slice(0, 16),
        valueSystolic: "",
        valueDiastolic: "",
        value: "",
        notes: "",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save the reading. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleCancel = () => {
    form.reset();
  };
  
  return (
    <div className="lg:col-span-2">
      <Card className="card hover:shadow-md transition-shadow">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4 font-montserrat">Record New Reading</h2>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="vitalType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-700">Reading Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full p-3 bg-neutral-50 border border-neutral-300 rounded-lg">
                            <SelectValue placeholder="Select reading type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Blood Pressure">Blood Pressure</SelectItem>
                          <SelectItem value="Heart Rate">Heart Rate</SelectItem>
                          <SelectItem value="Blood Oxygen">Blood Oxygen</SelectItem>
                          <SelectItem value="Temperature">Temperature</SelectItem>
                          <SelectItem value="Weight">Weight</SelectItem>
                          <SelectItem value="Blood Glucose">Blood Glucose</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="timestamp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-700">Date & Time</FormLabel>
                      <FormControl>
                        <Input 
                          type="datetime-local" 
                          className="w-full p-3 bg-neutral-50 border border-neutral-300 rounded-lg"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {isBloodPressure ? (
                  <div className="md:col-span-1">
                    <FormLabel className="text-sm font-medium text-neutral-700">Value</FormLabel>
                    <div className="flex">
                      <FormField
                        control={form.control}
                        name="valueSystolic"
                        render={({ field }) => (
                          <FormItem className="w-1/2">
                            <FormControl>
                              <Input 
                                type="text" 
                                placeholder="120" 
                                className="rounded-r-none bg-neutral-50 border border-neutral-300"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="w-px bg-neutral-300"></div>
                      <FormField
                        control={form.control}
                        name="valueDiastolic"
                        render={({ field }) => (
                          <FormItem className="w-1/2">
                            <FormControl>
                              <Input 
                                type="text" 
                                placeholder="80" 
                                className="rounded-l-none bg-neutral-50 border border-neutral-300"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormDescription className="text-xs text-neutral-500 mt-1">
                      For blood pressure, enter systolic/diastolic
                    </FormDescription>
                  </div>
                ) : selectedVitalType ? (
                  <FormField
                    control={form.control}
                    name="value"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-neutral-700">Value {unit && `(${unit})`}</FormLabel>
                        <FormControl>
                          <Input 
                            type="text" 
                            placeholder={`Enter ${selectedVitalType.toLowerCase()} value`}
                            className="w-full p-3 bg-neutral-50 border border-neutral-300 rounded-lg"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ) : null}
                
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-700">Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          rows={1}
                          placeholder="Any additional information..."
                          className="w-full p-3 bg-neutral-50 border border-neutral-300 rounded-lg resize-none"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="mt-6 flex justify-end">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleCancel}
                  className="bg-neutral-200 hover:bg-neutral-300 text-neutral-800 mr-3"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-primary hover:bg-primary-dark text-white px-6"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Saving..." : "Save Reading"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
