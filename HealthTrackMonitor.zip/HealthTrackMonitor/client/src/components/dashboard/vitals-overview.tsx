import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { formatTimeAgo, getStatusColor } from "@/lib/utils";
import { useWebSocket } from "@/lib/websocket";
import { useEffect, useState } from "react";
import { ChevronRight, Activity, Heart, Thermometer, Droplet } from "lucide-react";

interface VitalCardProps {
  title: string;
  value: string;
  unit: string;
  lastUpdated: string;
  status: string;
  icon: React.ReactNode;
  chartData: any[];
}

function VitalCard({ title, value, unit, lastUpdated, status, icon, chartData }: VitalCardProps) {
  return (
    <Card className="card hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-neutral-600">{title}</h3>
          <div className="text-teal-600">{icon}</div>
        </div>
        
        <div className="flex items-baseline">
          <span className="text-2xl font-semibold">{value}</span>
          <span className="ml-2 text-sm text-neutral-600">{unit}</span>
        </div>
        
        <div className="chart-container my-3 h-[100px]">
          <div className="h-full flex items-end">
            {chartData.map((item, index) => (
              <div 
                key={index}
                className={`${index >= chartData.length - 2 ? 'bg-primary' : 'bg-primary-light'} w-1/6 mx-1 rounded-t-sm`} 
                style={{ height: `${item.height}%` }}
              ></div>
            ))}
          </div>
        </div>
        
        <div className="flex items-center justify-between text-xs text-neutral-600">
          <span>Updated {lastUpdated}</span>
          <div className="flex items-center">
            <span className="material-icons text-success text-sm">trending_flat</span>
            <span className={`ml-1 ${getStatusColor(status)}`}>{status === 'normal' ? 'Normal' : status}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface VitalsOverviewProps {
  userId: number;
}

export default function VitalsOverview({ userId }: VitalsOverviewProps) {
  const [latestVitals, setLatestVitals] = useState<Record<string, any>>({});
  const [vitalHistoryData, setVitalHistoryData] = useState<Record<string, any>>({});
  
  const { lastMessage } = useWebSocket();
  
  // Fetch latest vitals from API
  const { data, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}/vitals/latest`],
  });
  
  // Process WebSocket messages
  useEffect(() => {
    if (lastMessage) {
      if (lastMessage.type === 'init') {
        setLatestVitals(lastMessage.latestVitals || {});
        setVitalHistoryData(lastMessage.vitalHistoryData || {});
      } else if (lastMessage.type === 'vitalUpdate') {
        setLatestVitals(prev => ({
          ...prev,
          [lastMessage.vital.type]: lastMessage.vital
        }));
        
        setVitalHistoryData(prev => ({
          ...prev,
          [lastMessage.vital.type]: lastMessage.history
        }));
      }
    }
  }, [lastMessage]);
  
  // Use API data if WebSocket data is not available yet
  useEffect(() => {
    if (data && Object.keys(latestVitals).length === 0) {
      setLatestVitals(data);
    }
  }, [data, latestVitals]);
  
  // Mock chart data when real data is not available
  const generateMockChartData = () => {
    return Array(6).fill(0).map(() => ({
      height: 50 + Math.random() * 50,
    }));
  };
  
  if (isLoading && Object.keys(latestVitals).length === 0) {
    return (
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold font-montserrat">Recent Vitals</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="h-32 bg-gray-200 rounded-md"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }
  
  const vitalTypes = [
    { 
      key: 'Blood Pressure', 
      title: 'Blood Pressure', 
      unit: 'mmHg', 
      icon: <Activity className="h-5 w-5" /> 
    },
    { 
      key: 'Heart Rate', 
      title: 'Heart Rate', 
      unit: 'bpm', 
      icon: <Heart className="h-5 w-5" /> 
    },
    { 
      key: 'Blood Oxygen', 
      title: 'Blood Oxygen', 
      unit: '%', 
      icon: <Droplet className="h-5 w-5" /> 
    },
    { 
      key: 'Temperature', 
      title: 'Temperature', 
      unit: '°F', 
      icon: <Thermometer className="h-5 w-5" /> 
    }
  ];
  
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold font-montserrat">Recent Vitals</h2>
        <Link href="/vitals">
          <a className="text-primary text-sm font-medium flex items-center hover:underline">
            View All
            <ChevronRight className="ml-1 h-4 w-4" />
          </a>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {vitalTypes.map((vitalType) => {
          const vital = latestVitals[vitalType.key];
          const chartData = vitalHistoryData[vitalType.key] || generateMockChartData();
          
          if (!vital) {
            return (
              <Card key={vitalType.key} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-32 bg-gray-200 rounded-md"></div>
                </CardContent>
              </Card>
            );
          }
          
          return (
            <VitalCard
              key={vitalType.key}
              title={vitalType.title}
              value={vital.value}
              unit={vital.unit}
              lastUpdated={formatTimeAgo(vital.timestamp)}
              status={vital.status || 'normal'}
              icon={vitalType.icon}
              chartData={chartData.length > 0 ? chartData : generateMockChartData()}
            />
          );
        })}
      </div>
    </div>
  );
}
