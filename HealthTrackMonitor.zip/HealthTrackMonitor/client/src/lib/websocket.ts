import React, { createContext, useContext, useEffect, useRef, useState, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";

interface WebSocketContextType {
  send: (message: any) => void;
  lastMessage: any;
  connected: boolean;
}

const WebSocketContext = createContext<WebSocketContextType>({
  send: () => {},
  lastMessage: null,
  connected: false,
});

interface WebSocketProviderProps {
  children: ReactNode;
  userId: number;
}

export const WebSocketProvider = ({ children, userId }: WebSocketProviderProps): JSX.Element => {
  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    socket.onopen = () => {
      console.log("WebSocket connected");
      setConnected(true);
      
      // Send authentication message with userId
      socket.send(JSON.stringify({
        type: "auth",
        userId: userId,
      }));
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setLastMessage(data);
        
        // Handle success and error messages with toast notifications
        if (data.type === "success") {
          toast({
            title: "Success",
            description: data.message,
            variant: "default",
          });
        } else if (data.type === "error") {
          toast({
            title: "Error",
            description: data.message,
            variant: "destructive",
          });
        }
      } catch (err) {
        console.error("Error parsing message:", err);
      }
    };

    socket.onclose = () => {
      console.log("WebSocket disconnected");
      setConnected(false);
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
      toast({
        title: "Connection Error",
        description: "Failed to connect to the server. Please try again later.",
        variant: "destructive",
      });
    };

    // Clean up on unmount
    return () => {
      socket.close();
    };
  }, [userId, toast]);

  const send = (message: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(message));
    } else {
      console.error("WebSocket is not connected");
      toast({
        title: "Connection Error",
        description: "Not connected to the server. Please refresh the page.",
        variant: "destructive",
      });
    }
  };

  return React.createElement(
    WebSocketContext.Provider,
    { value: { send, lastMessage, connected } },
    children
  );
};

export const useWebSocket = () => useContext(WebSocketContext);
