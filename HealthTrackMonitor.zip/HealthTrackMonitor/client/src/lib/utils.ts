import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { formatDistanceToNow } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTimeAgo(date: Date | string) {
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

export function getStatusColor(status: string) {
  switch (status.toLowerCase()) {
    case 'normal':
      return 'text-green-500';
    case 'warning':
      return 'text-amber-500';
    case 'critical':
      return 'text-red-500';
    default:
      return 'text-gray-500';
  }
}

export function getVitalUnit(type: string) {
  switch (type) {
    case 'Blood Pressure':
      return 'mmHg';
    case 'Heart Rate':
      return 'bpm';
    case 'Blood Oxygen':
      return '%';
    case 'Temperature':
      return '°F';
    case 'Weight':
      return 'lbs';
    case 'Blood Glucose':
      return 'mg/dL';
    default:
      return '';
  }
}

export function getNotificationIcon(type: string) {
  switch (type) {
    case 'medication':
      return 'medical_services';
    case 'appointment':
      return 'calendar_today';
    case 'alert':
      return 'warning';
    case 'message':
      return 'message';
    default:
      return 'notifications';
  }
}

export function getNotificationColorClass(type: string) {
  switch (type) {
    case 'medication':
      return 'bg-primary/10 text-primary';
    case 'appointment':
      return 'bg-info/10 text-info';
    case 'alert':
      return 'bg-warning/10 text-warning';
    case 'message':
      return 'bg-success/10 text-success';
    default:
      return 'bg-neutral-100 text-neutral-600';
  }
}

export function getTrendIcon(current: number, previous: number) {
  if (current > previous) {
    return { icon: 'trending_up', class: 'text-red-500' };
  } else if (current < previous) {
    return { icon: 'trending_down', class: 'text-green-500' };
  } else {
    return { icon: 'trending_flat', class: 'text-green-500' };
  }
}

export function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}
