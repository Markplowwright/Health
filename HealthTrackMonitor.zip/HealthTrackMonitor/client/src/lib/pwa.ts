// Register the service worker for PWA functionality
export function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
      try {
        // Check if service worker is already registered
        const existingRegistration = await navigator.serviceWorker.getRegistration();
        
        if (existingRegistration) {
          console.log('Service worker already registered with scope:', existingRegistration.scope);
          
          // Update the service worker if needed
          try {
            await existingRegistration.update();
            console.log('Service worker updated successfully');
          } catch (updateError) {
            console.warn('Service worker update failed:', updateError);
          }
          
          return existingRegistration;
        }

        // Register new service worker
        const registration = await navigator.serviceWorker.register('/sw.js', {
          scope: '/' // Explicitly set scope to root
        });
        
        console.log('ServiceWorker registration successful with scope: ', registration.scope);

        // Setup periodic sync if browser supports it
        // Note: periodicSync is an experimental API and may not be available in all browsers
        try {
          // @ts-ignore - Experimental API
          if (registration.periodicSync) {
            // @ts-ignore - Experimental API
            await registration.periodicSync.register('sync-vitals', {
              minInterval: 60 * 60 * 1000, // Once per hour
            });
            console.log('Periodic sync registered');
          }
        } catch (error) {
          console.error('Periodic sync could not be registered:', error);
        }
        
        return registration;
      } catch (error) {
        console.error('ServiceWorker registration failed: ', error);
        return null;
      }
    });
  }
}

// Handler for push notifications
export async function registerForPushNotifications() {
  if (!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) {
    console.warn('Push notifications not supported');
    return false;
  }

  // Request notification permission
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    console.warn('Notification permission not granted');
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(
        // Public key should come from server
        'BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8U'
      ),
    });
    
    console.log('Push subscription:', JSON.stringify(subscription));
    
    // Here you would send subscription to server
    await sendSubscriptionToServer(subscription);
    
    return true;
  } catch (error) {
    console.error('Failed to subscribe for push:', error);
    return false;
  }
}

// Convert base64 string to Uint8Array for push registration
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Send push subscription to server
async function sendSubscriptionToServer(subscription: PushSubscription) {
  // Implementation would send to server
  console.log('Would send subscription to server:', subscription);
  return true;
}

// Check and handle installability of the PWA
export function checkIfInstallable() {
  // Storage for install prompt
  let deferredPrompt: any = null;
  let isInstallable = false;

  // Listen for the beforeinstallprompt event
  window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent the mini-infobar from appearing on mobile
    e.preventDefault();
    // Stash the event so it can be triggered later
    deferredPrompt = e;
    // Update installable state
    isInstallable = true;
    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent('pwainstallable', { detail: true }));
  });

  // Handle installed event
  window.addEventListener('appinstalled', () => {
    // Log app install
    console.log('PWA installed successfully');
    // Clear the prompt
    deferredPrompt = null;
    isInstallable = false;
    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent('pwainstalled'));
  });

  // Return utilities
  return {
    // Get prompt for showing install prompt
    getDeferredPrompt: () => deferredPrompt,
    
    // Check if app can be installed
    isAppInstallable: () => isInstallable,
    
    // Trigger install prompt
    promptInstall: async () => {
      if (!deferredPrompt) {
        return false;
      }
      
      // Show prompt
      deferredPrompt.prompt();
      
      // Wait for user choice
      const choiceResult = await deferredPrompt.userChoice;
      
      // Clear prompt
      deferredPrompt = null;
      isInstallable = false;
      
      // Dispatch event for UI updates
      window.dispatchEvent(new CustomEvent('pwainstallable', { detail: false }));
      
      return choiceResult.outcome === 'accepted';
    },
    
    // Clear the prompt manually
    clearDeferredPrompt: () => {
      deferredPrompt = null;
      isInstallable = false;
    }
  };
}

// Check for online/offline status and provide utilities
export function useOnlineStatus() {
  const isOnline = () => navigator.onLine;
  
  const setupListeners = (
    onlineCallback: () => void,
    offlineCallback: () => void
  ) => {
    window.addEventListener('online', onlineCallback);
    window.addEventListener('offline', offlineCallback);
    
    // Return cleanup function
    return () => {
      window.removeEventListener('online', onlineCallback);
      window.removeEventListener('offline', offlineCallback);
    };
  };
  
  return {
    isOnline,
    setupListeners
  };
}

// Store vitals data in IndexedDB when offline
export async function storeOfflineVitals(vital: any) {
  if (!('indexedDB' in window)) {
    console.error('IndexedDB not supported');
    return false;
  }
  
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('HealthConnectDB', 1);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('offlineVitals')) {
        db.createObjectStore('offlineVitals', { keyPath: 'id', autoIncrement: true });
      }
    };
    
    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const transaction = db.transaction(['offlineVitals'], 'readwrite');
      const store = transaction.objectStore('offlineVitals');
      
      const addRequest = store.add(vital);
      
      addRequest.onsuccess = () => {
        resolve(true);
        
        // Request background sync if available
        if ('serviceWorker' in navigator && 'SyncManager' in window) {
          navigator.serviceWorker.ready
            .then(registration => {
              // @ts-ignore - SyncManager API might not be recognized by TypeScript
              if (registration.sync) {
                // @ts-ignore - SyncManager API might not be recognized by TypeScript
                registration.sync.register('sync-vitals')
                  .catch((err: Error) => console.error('Background sync registration failed:', err));
              }
            });
        }
      };
      
      addRequest.onerror = () => {
        reject(addRequest.error);
      };
      
      transaction.oncomplete = () => {
        db.close();
      };
    };
    
    request.onerror = () => {
      reject(request.error);
    };
  });
}