import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Vitals from "@/pages/vitals";
import Medications from "@/pages/medications";
import Appointments from "@/pages/appointments";
import Messages from "@/pages/messages";
import Profile from "@/pages/profile";
import Header from "@/components/layout/header";
import Navigation from "@/components/layout/navigation";
import Footer from "@/components/layout/footer";
import { useState, useEffect } from "react";
import { WebSocketProvider } from "@/lib/websocket";

function AppContent() {
  const [location] = useLocation();
  // Hardcoded user ID for demonstration
  const userId = 1;

  return (
    <div className="flex flex-col min-h-screen">
      <Header userId={userId} />
      <Navigation currentPath={location} />
      <main className="flex-grow container mx-auto px-4 py-6">
        <Switch>
          <Route path="/" component={() => <Dashboard userId={userId} />} />
          <Route path="/vitals" component={() => <Vitals userId={userId} />} />
          <Route path="/medications" component={() => <Medications userId={userId} />} />
          <Route path="/appointments" component={() => <Appointments userId={userId} />} />
          <Route path="/messages" component={() => <Messages userId={userId} />} />
          <Route path="/profile" component={() => <Profile userId={userId} />} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  // Hardcoded user ID for demonstration
  const userId = 1;

  return (
    <QueryClientProvider client={queryClient}>
      <WebSocketProvider userId={userId}>
        <AppContent />
      </WebSocketProvider>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
