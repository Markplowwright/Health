import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  dateOfBirth: text("date_of_birth"),
  careTeam: text("care_team"),
  monitoringSince: text("monitoring_since"),
  nextCheckIn: text("next_check_in"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const vitals = pgTable("vitals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // Blood Pressure, Heart Rate, Blood Oxygen, Temperature, etc.
  value: text("value").notNull(), // For BP: "120/80", for others: "72", "98", "98.6"
  unit: text("unit").notNull(), // mmHg, bpm, %, °F, etc.
  timestamp: timestamp("timestamp").notNull(),
  notes: text("notes"),
  status: text("status").default("normal"), // normal, warning, critical
});

export const insertVitalSchema = createInsertSchema(vitals).omit({
  id: true,
});

export type InsertVital = z.infer<typeof insertVitalSchema>;
export type Vital = typeof vitals.$inferSelect;

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // medication, appointment, alert, message
  isRead: boolean("is_read").default(false),
  timestamp: timestamp("timestamp").notNull(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

export const vitalHistory = pgTable("vital_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  data: json("data").notNull(), // Array of historical readings for charts
  updatedAt: timestamp("updated_at").notNull(),
});

export const insertVitalHistorySchema = createInsertSchema(vitalHistory).omit({
  id: true,
});

export type InsertVitalHistory = z.infer<typeof insertVitalHistorySchema>;
export type VitalHistory = typeof vitalHistory.$inferSelect;
